# Privacy Policy

Date:12/9/2020

Game Saver will not save ANYTHING, everything you do is done locally.

No data is sent back to any server, nor is there any external communication of any kind. All data is yours and stored locally in local storage for the extension. Syncrinization in the plugin may occur for the state of the extension.
Your data is your data, game saver doesn't want it.

