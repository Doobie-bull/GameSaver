# GameSaver
Save the Flash!

This project is a last ditch effort to grab as many files as possible to save as many flash games as possible.
All you have to do is install the extension, then play flash games while it is enabled. It will automatically save the links related directly to flash and flash requested files.

Then you simply hit the download button and it will zip and save them off. The goal is to play as many games as you can, downloading them to save them off.

TODO: add more information.

Thanks!
