//Model Pages, how to get the deploy button
//  $(".pull-right [title='Deploy']")[0]

//Add button, then add custom url variable to choose the type